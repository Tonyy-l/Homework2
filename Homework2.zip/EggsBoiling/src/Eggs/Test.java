package Eggs;

import java.util.Scanner;


public class Test {
	

	public static void main(String[] args) {
		
		int mins = 0;
		int eggs=0;
	
	Scanner input = new Scanner(System.in);
	
	System.out.println("Please enter the minutes of boiling: ");
	 
	String min = input.nextLine();
	
	if (mins > 0 || mins <= 3) { 
		System.out.println("They are soft ");
	}
	
	else if (mins > 3 || mins <= 5) {
		
		System.out.println("They are still soft. ");
	}
	 
	else if(mins > 5) {
		System.out.println("They are hard. ");
	}
	
	else {
		System.out.println("Incorrect value, please enter real minutes!");
	}
	
	// end of time.
	
	System.out.print("Enter the number of eggs "); 
	
	min = input.nextLine();

	
	if (eggs > 0 || eggs <= 3) {
		System.out.println("You have to use jazz! ");
	}
		else if (eggs > 3 || eggs <= 6) {
		System.out.print("You have to use mug!");
		
	}
		else if(eggs > 6) {
			System.out.println("You have to use the pot!");
		}
		
		else {
			System.out.print("Incorrect values");
		}
	}
}
	
			
		
	

	



