package Eggs;

import java.util.Scanner;

class Products {
	
	String cookwares;
	int eggs=0;
	
}
