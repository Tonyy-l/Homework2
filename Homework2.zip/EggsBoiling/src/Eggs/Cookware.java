package Eggs;

import java.util.ArrayList;

public class Cookware  {
	
	public Cookware() {
		ArrayList<String> Cookwares = new ArrayList<String>();
		Cookwares.add("Jazz");
		Cookwares.add("Mug");
		Cookwares.add("Pot");
		
	}
	
	

}
